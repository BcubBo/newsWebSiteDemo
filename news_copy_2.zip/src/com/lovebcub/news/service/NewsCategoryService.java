package com.lovebcub.news.service;

import java.util.List;

import com.lovebcub.news.entity.NewsCategory;

public interface NewsCategoryService {

	//获取新闻分类信息表
	public List<NewsCategory> getNewsCategoryList();

	
	
	
}
