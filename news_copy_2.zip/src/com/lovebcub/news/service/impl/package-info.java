/**
 * 
 */
/**
 * @author fatal
 *
 */
package com.lovebcub.news.service.impl;