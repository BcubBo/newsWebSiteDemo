/**
 * 
 */
/**
 * @author fatal
 *
 */
package com.lovebcub.news.mainStart;